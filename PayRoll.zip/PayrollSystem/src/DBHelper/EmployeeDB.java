package DBHelper;

import Employee.EmployeeModel;
import java.sql.*;

/**
 *
 * 
 */
public class EmployeeDB {
    
    public static ResultSet LoadEmployeeList(Connection conn){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "Select e.*, em.EmpSelary from Employee e inner join EmpSelary em on e.EmpID = em.EmpID";
            rs = state.executeQuery(q);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadEmployeeLastID(Connection conn){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select TOP(1) * from Employee Order by EmpID DESC";
            rs = state.executeQuery(q);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadEmployeeByID(Connection conn, int id){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from Employee Where EmpID = "+ id;
            rs = state.executeQuery(q);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadEmployeeSalaryByID(Connection conn, int id){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from EmpSelary Where EmpID = "+ id;
            rs = state.executeQuery(q);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
                   
    public static void saveEmployee(Connection conn, String name, String contact, String address, String designation, Date jDate, Date dob){
        try{
            Statement state = conn.createStatement();
            
            String q = "INSERT INTO EMPLOYEE " + "VALUES('"+name+"', '"
                                     +designation+"', '"+contact+"', '"
                                     +address+"', '"+jDate+"', '"+dob+"')";                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void saveEmpSalary(Connection conn, int EmpID, int SalID, Date joinDate){
        try{
            Statement state = conn.createStatement();
            
            //System.out.println(EmpID+", "+SalID+", "+joinDate);
            
            String q = "INSERT INTO EmpSelary " + "VALUES("+EmpID+", "+SalID+", '"+joinDate+"',"+null+")";                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        } 
    }
    
    public static void updateEmployee(Connection conn, int EmpID, String name, String contact, String address, String designation, Date jDate, Date dob){
        try{
            Statement state = conn.createStatement();
            
            String q = "UPDATE EMPLOYEE SET NAME = '"+name
                                       +"', POST = '"+designation
                                       +"', CONTACT = '"+contact
                                       +"', ADDRESS = '"+address
                                       +"', JOININGDATE = '"+jDate
                                       +"', DATEOFBIRTH = '"+dob+"' WHERE EMPID = "+EmpID;                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void updateEmpSalary(Connection conn, int EmpID, int SalID, Date joinDate, int increment, double empSal){
        try{
            Statement state = conn.createStatement();
            
            String q = "UPDATE EMPSELARY SET SELARYDAY = '"+joinDate+"', INCREMENT = "+increment+", EMPSELARY = "+empSal+" WHERE EMPID = "+EmpID;                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void deleteEmployee(Connection conn, int EmpID){
        try{
            Statement state = conn.createStatement();
            String q = "DELETE FROM EMPLOYEE WHERE EMPID = "+ EmpID;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
}
