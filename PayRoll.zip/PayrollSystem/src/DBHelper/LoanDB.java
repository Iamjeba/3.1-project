/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DBHelper;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * 
 */
public class LoanDB {
    
    public static ResultSet LoadEmpLoanList(Connection conn){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from emploan";
            rs = state.executeQuery(q);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadEmpLoanByID(Connection conn, int id){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from emploan where emploanid = "+id;
            rs = state.executeQuery(q);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadLoanList(Connection conn){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from loan";
            rs = state.executeQuery(q);            
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadLoanByID(Connection conn, int id){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from loan where loanid = "+ id;
            rs = state.executeQuery(q);            
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static void saveEmpLoan(Connection conn, int empID, int loanID, int duration, int interest, Date takenDate, String loanName){
        try{
            Statement state = conn.createStatement();
            
            String q = "INSERT INTO EMPLOAN " + "VALUES("+empID+", "+loanID+", '"+takenDate+"', "+duration+", '"+loanName+"', "+interest+")";                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void saveLoan(Connection conn, double amount, int duration, int loanType, String loanName){
        try{
            Statement state = conn.createStatement();
            
            System.out.println(amount+" "+duration+" "+loanType+" "+loanName);
            
            String q = "INSERT INTO LOAN " + "VALUES("+amount+", "+duration+", "+loanType+", '"+loanName+"')";                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void updateEmpLoan(Connection conn, int empID, int loanID, int duration, int interest, Date takenDate, String loanName, Double Totalamount, int id){
        try{
            Statement state = conn.createStatement();
            
            String q = "UPDATE EMPLOAN SET EMPID = "+empID+", LOANID = "+loanID+", INTEREST = "+interest+", LOANNAME = '"+loanName+"',DURATION = "+duration+", TAKENDATE = '"+takenDate+"', Amount = "+Totalamount+" WHERE EMPLOANID = "+id;                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void editLoan(Connection conn, double amount, int duration, int loanType, String loanName, int id){
        try{
            Statement state = conn.createStatement();
            String q = "UPDATE LOAN SET LOANTYPE = "+loanType+", LOANNAME = '"+loanName+"', DURATION = "+duration+", AMOUNT = "+amount+" WHERE LOANID = "+ id;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void deleteLoan(Connection conn, int id){
        try{
            Statement state = conn.createStatement();
            String q = "DELETE FROM LOAN WHERE LOANID = "+ id;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void deleteEmpLoan(Connection conn, int ID){
        try{
            Statement state = conn.createStatement();
            String q = "DELETE FROM EMPLOAN WHERE EMPLOANID = "+ ID;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
}
