/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DBHelper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * 
 */
public class SalaryDB {
    
    public static void saveSalary(Connection conn, String designation, double salary, double scale){
        try{
            Statement state = conn.createStatement();
            String q = "INSERT INTO SELARY " + "VALUES("+scale+", "+salary+", '"+designation+"')";
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static ResultSet LoadSalaryList(Connection conn){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from selary";
            rs = state.executeQuery(q);            
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadSalaryByID(Connection conn, int id){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from selary where selid = "+ id;
            rs = state.executeQuery(q);            
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadSalaryByPost(Connection conn, String post){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from selary where post = '"+post+"'";
            rs = state.executeQuery(q);            
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static void editSalary(Connection conn, String designation, double salary, double scale, int SalID){
        try{
            Statement state = conn.createStatement();
            String q = "UPDATE SELARY SET POST = '"+designation+"', SELARY = "+salary+", SCALE = "+scale+" WHERE SELID = "+ SalID;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void deleteSalary(Connection conn, int SalID){
        try{
            Statement state = conn.createStatement();
            String q = "DELETE FROM SELARY WHERE SELID = "+ SalID;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
}
