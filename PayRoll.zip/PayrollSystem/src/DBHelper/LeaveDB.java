/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DBHelper;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * 
 */
public class LeaveDB {
    
    public static ResultSet LoadEmpLeaveList(Connection conn){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from empleave";
            rs = state.executeQuery(q);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadEmpLeaveByID(Connection conn, int id){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from empleave where id = "+id;
            rs = state.executeQuery(q);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadLeaveList(Connection conn){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from leave";
            rs = state.executeQuery(q);            
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static ResultSet LoadLeaveByID(Connection conn, int id){
        ResultSet rs = null;
        
        try{
            Statement state = conn.createStatement();
            String q = "select * from leave where id = "+ id;
            rs = state.executeQuery(q);            
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }      
        
        return rs;
    }
    
    public static void saveEmpLeave(Connection conn, int empID, int leaveID, int duration, int leaveType, Date sDate, Date eDate, String leaveReason){
        try{
            Statement state = conn.createStatement();
            
            String q = "INSERT INTO EMPLEAVE " + "VALUES("+empID+", "
                                     +leaveID+", "+leaveType+", '"
                                     +leaveReason+"', "+duration+", '"+sDate+"','"+eDate+"')";                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void saveLeave(Connection conn, int duration, int leaveType, String leaveName){
        try{
            Statement state = conn.createStatement();
            
            String q = "INSERT INTO LEAVE " + "VALUES("+leaveType+", '"+leaveName+"', "+duration+")";                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void updateEmpLeave(Connection conn, int empID, int leaveID, int duration, int leaveType, Date sDate, Date eDate, String leaveReason, int id){
        try{
            Statement state = conn.createStatement();
            
            String q = "UPDATE EMPLEAVE SET EMPID = "+empID
                                       +", LEAVEID = "+leaveID
                                       +", LEAVETYPE = "+leaveType
                                       +", LEAVEREASON = '"+leaveReason+"',DURATION = "+duration+", STARTDATE = '"+sDate+"', ENDDATE = '"+eDate+"' WHERE ID = "+id;                       
            
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void editLeave(Connection conn, int duration, int leaveType, String leaveName, int leaveID){
        try{
            Statement state = conn.createStatement();
            String q = "UPDATE LEAVE SET LEAVETYPE = "+leaveType+", LEAVENAME = '"+leaveName+"', DURATION = "+duration+" WHERE ID = "+ leaveID;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void deleteLeave(Connection conn, int LeaveID){
        try{
            Statement state = conn.createStatement();
            String q = "DELETE FROM LEAVE WHERE ID = "+ LeaveID;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
    
    public static void deleteEmpLeave(Connection conn, int ID){
        try{
            Statement state = conn.createStatement();
            String q = "DELETE FROM EMPLEAVE WHERE ID = "+ ID;
            state.executeUpdate(q);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }  
    }
}
