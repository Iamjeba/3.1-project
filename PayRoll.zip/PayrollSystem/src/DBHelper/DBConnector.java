/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DBHelper;

import java.sql.*;

/**
 *
 * 
 */
public class DBConnector {
    
    public static Connection ConnectToDB(){
        Connection connection = null;
        try{
            
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String dbUrl = "jdbc:sqlserver://localhost\\SQLEXPRESS:1433;databaseName=PayRoll;integratedSecurity=true";
            connection = DriverManager.getConnection(dbUrl);
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        return connection;
    }
    
}
